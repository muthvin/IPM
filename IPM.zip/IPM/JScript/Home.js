 /*************** Login Page **********************/
//declare Variable
var Project = "";
var Role = "";
var Metrics = "";

// function to validate user and password fields
function validate()
{
	if(isValidCredntial())
	{
		var xhttp = new XMLHttpRequest();
		var user = document.getElementById("Txt_Username").value.trim();
		var pwd = document.getElementById("Txt_Password").value.trim();

		var fd = new FormData();
		fd.append("Txt_Username",user);
		fd.append("Txt_Password",pwd);
		localStorage.setItem("username",user);

		xhttp.addEventListener("error", login_error, false);
		xhttp.onreadystatechange = function() {
			
			if ((this.readyState == 4) && (this.status == 200))
			{
				var response_txt = this.responseText.split(" ");
				response_code = response_txt[0]
				response_code = response_code.trim()
				if(response_code == "UAP1")
				{
					if(response_txt[1] != "")
					{
						Project = response_txt[1];
					}
					if(response_txt[2] != "")
					{
						Role = response_txt[2];
					}
					if(response_txt[3] != "")
					{
						userid = response_txt[3];
					}
					if(response_txt[4] != "")
					{
						prjid = response_txt[4];
					}
					window.location = 'Welcome.html';

					localStorage.setItem("username",user);
					localStorage.setItem("Project",Project);
					localStorage.setItem("UserId",userid);
					localStorage.setItem("PrjId",prjid);
					localStorage.setItem("Role",Role);
				}
				else
				{
					if(response_code == "UAP0")
					{
						alert("Please enter a valid UserName and Password");
						var l=document.getElementById('Div_loginBlock');
						l.style.display = 'block';
						var home= document.getElementById('homepage');
						home.style.display ='none';
					}
				}
			}
			
			
		};
		xhttp.open("POST", "../cgi-bin/userAuth.py?user="+user, true);
		xhttp.send(fd);
	}
}

// function to validate the username and password field
function isValidCredntial()
{
	//var re = new RegExp("^[a-z][a-z0-9_]*");
	if(document.getElementById("Txt_Username").value.trim() == "")
	{
		alert("Please enter 'User Name'");
		return false;
	}
	else if(document.getElementById("Txt_Password").value.trim() == "")
	{
		alert("Please enter 'Password'");
		return false;
	}
	else
	{
		return true;
	}
}

// function to login error message
function login_error() {
	alert("Enter valid login credential");
}