/*************** LAPAM Page **********************/
var Output_StringPath = "";
var startdateval ="";
var field_data = [];
var fieldval = "";
var usagepattern_chk = false, datacomb_chk = false, failureanal_chk = false, businesstran_chk = false;
var uploaded_filepath =""
var testalready_exists = /TAP 0/g;
var sapfile_chk = /FUP 0/;

// function to enable the option of uploading Test log file
// function created as part of story ST05
function checkbox_test()
{
	if(check_box.checked)
	{
		Dlg_serverfile.disabled = false;
	}
	else
	{
		Dlg_serverfile.disabled = true;
	}
}

// function to call on body load
// function created as part of story ST04
function LapamPage_onload()
{
	if(localStorage.getItem("QualContent") == "New")
	{
		document.getElementById("ifm_content").src = "NewQualifier.html";
		parent.ifm_link.contentWindow.document.getElementById("qualify_link").text = "Qualify";
		parent.ifm_link.contentWindow.document.getElementById("qualify_link").style.textDecoration = "underline";
		parent.ifm_link.contentWindow.document.getElementById("qualify_link").style.display = "none";
	}
	else
	{
		document.getElementById("ifm_content").src = "ViewQualifier.html";
		parent.ifm_link.contentWindow.document.getElementById("qualify_link").text = "View";
		parent.ifm_link.contentWindow.document.getElementById("qualify_link").style.textDecoration = "underline";
	}
}

// function to call on body load
// function created as part of story ST05
function Page_onload()
{
	document.getElementById("Txt_Projectname").value = localStorage.getItem("Project");
	document.getElementById("Btn_Qualify").disabled = true;
}

// function to call on body load
// function created as part of story ST06
function ViewPage_onload()
{
	document.getElementById("Txt_view_Projectname").value = localStorage.getItem("Project");
	getExistingReportname();
}
//function to validate report name field
// function created as part of story ST05
function isValidreportname()
{ 
	var reportname_regex = /^[a-zA-Z]{1}[0-9a-zA-Z_-]*$/;
	if(document.getElementById("Txt_reportname").value.trim() == "")
	{
		alert("Please enter 'Log Name'");
		return false;
	}
	else if(!document.getElementById("Txt_reportname").value.trim().match(reportname_regex))
	{
		alert("Please enter valid log name");
		return false;
	}
	else if(document.getElementById("Dlg_filename").value == "")
	{
		alert("Kindly upload log file to proceed further");
		return false;
	}
	else if (document.getElementById("Dlg_filename").value.lastIndexOf(".") > 0) {
		fileExtension = document.getElementById("Dlg_filename").value.substring(document.getElementById("Dlg_filename").value.lastIndexOf(".") + 1, document.getElementById("Dlg_filename").value.length);
        
        if (fileExtension.toLowerCase() == "txt" || fileExtension.toLowerCase() == "log" || fileExtension.toLowerCase() == "zip" ||fileExtension.toLowerCase() == "csv" || fileExtension.toLowerCase() == "xls" ||fileExtension.toLowerCase() == "xlsx"||fileExtension.toLowerCase() == "xml"||fileExtension.toLowerCase() == "001") {
            return true;
        }
        else {
            alert("Kindly select a valid file for upload");
            return false;
        }
	}
	else
	{
		return true;
	}
}

// function to fetch report details
// function created as part of story ST06
function getExistingReportname()
{
	var xhttp = new XMLHttpRequest();
	var fd = new FormData();
	fd.append("prj_id",localStorage.getItem("PrjId"));
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var outputVal = this.responseText.trim();
			var output_mat = outputVal.match(/\[\]/g);
			if(outputVal != "" && output_mat != "[]")
			{
				var test_drp = document.getElementById("Drp_View_reportname");	
				var test_length = test_drp.options.length;
				for (i = 0; i < test_length; i++) {
				  test_drp.options[0] = null;
				}
				var project_name_arr = this.responseText.split("'");
				for (var prj_i=1; prj_i<project_name_arr.length ; prj_i=prj_i+2) {					
					var option = document.createdElement("option");
					option.text = project_name_arr[prj_i];
					test_drp.add(option, test_drp[0]);
				} 
			}
			else{
				alert("Kindly analyze a log file to view this page");
				document.getElementById("Btn_exist_proceed").disabled = true;
			}
		}
     };
     xhttp.open("POST", "../cgi-bin/getReportName.py",true);
     xhttp.send(fd);
}


// function to call on body load
// function created as part of story ST04
function showQual()
{
	if(localStorage.getItem("QualContent") == "New")
	{
		parent.ifm_content.src = "NewQualifier.html";
	}
	else
	{
		parent.ifm_content.src = "ViewQualifier.html";
	}
	var divlink = parent.ifm_link.contentWindow.document.getElementById("Div_link");
	for(var div_i=divlink.childNodes.length-1; div_i > 3; div_i--)
	{
		divlink.removeChild(divlink.childNodes[div_i]);
	}
}

// function to call on Home click
// function created as part of story ST04
function Home()
{
	parent.window.location.href = "Welcome.html";
}

// function to call on Home click
// function created as part of story ST04
function Logout()
{
	parent.window.location.href = "Home.html";
}

 
//function to validate field
// function created as part of story ST03
function isValidField()
{ 
	var field_regex = /^[a-zA-Z0-9_.]+$/;
	var clientfield_regex = /^[0-9a-zA-Z_.]+$/;
	var email_regex = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	if(document.getElementById("Txt_Username").value.trim() == "")
	{
		alert("Please enter 'User Name'");
		return false;
	}
	else if(!document.getElementById("Txt_Username").value.match(field_regex))
	{
		alert("Please enter valid 'User Name'");
		return false;
	}
	else if(document.getElementById("Txt_Projname").value.trim() == "")
	{
		alert("Please enter 'Project Name'");
		return false;
	}
	else if(!document.getElementById("Txt_Projname").value.match(field_regex))
	{
		alert("Please enter valid 'Project Name'");
		return false;
	}
	else if(document.getElementById("Txt_emailid").value.trim() == "")
	{
		alert("Please enter 'Email Id'");
		return false;
	}
	else if(!document.getElementById("Txt_emailid").value.match(email_regex))
	{
		alert("Please enter valid 'Email Id'");
		return false;
	}
	else
	{
		return true;
	}
}
 
 //function for uploading files
 //function created as part of ST007
function upload_files(){
	if(isValidreportname())
	{	
		document.getElementById('Btn_Qualify').disabled = true;	
		parent.document.getElementById('top').style.display = 'block';
		parent.document.getElementById('div_Progressbar').style.display = 'block';
		var xhttp = new XMLHttpRequest();
		var fd = new FormData();
		var reportname = document.getElementById('Txt_reportname').value;
		localStorage.setItem("reportname",reportname);
		fd.append("Txt_reportname",reportname);
		fd.append("userid",localStorage.getItem("UserId"));
		fd.append("prjid",localStorage.getItem("PrjId"));
		var uploadedFile_len = document.getElementById("Dlg_filename").files.length;
		for (var file_i = 0; file_i < uploadedFile_len; file_i++) {
			fd.append("Dlg_filename", document.getElementById('Dlg_filename').files[file_i]);
			uploadFile_size = document.getElementById('Dlg_filename').files[file_i].size;
		}

		xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(!testalready_exists.test(this.responseText.toString()))
			{
				alert("File uploaded successfully");
				localStorage.setItem("uploaded_StringPath",this.responseText.toString().trim());
				document.getElementById('Txt_reportname').disabled = true;
				document.getElementById('Btn_upload').disabled = true;
				document.getElementById('Dlg_filename').disabled = true;
				document.getElementById('Btn_Qualify').disabled = false;
				parent.document.getElementById('top').style.display = 'none';
			}
			else
			{
				alert("Reportname already exists");
				parent.document.getElementById('top').style.display = 'none';
			}
	   }
	   else if (this.readyState == 4 && this.status == 208) {
				alert("Fail to upload");
				parent.document.getElementById('top').style.display = 'none';
		}
		};
		xhttp.open("POST", "../cgi-bin/upload.py?user="+localStorage.getItem('username')+"&logname="+reportname+"", true);
		xhttp.send(fd);
	}
}

 function loadQualDoc() {
	if(isValidreportname())
	{		
		parent.document.getElementById('top').style.display = 'block';
		parent.document.getElementById('div_Progressbar').style.display = 'block';
		var xhttp = new XMLHttpRequest();
		var fd = new FormData();
		var reportname = document.getElementById('Txt_reportname').value;
		localStorage.setItem("reportname",reportname);
		fd.append("Txt_reportname",reportname);
		fd.append("username",localStorage.getItem("username"));
		fd.append("userid",localStorage.getItem("UserId"));
		fd.append("prjid",localStorage.getItem("PrjId"));
		fd.append("uploaded_path",localStorage.getItem("uploaded_StringPath"));
		var uploadedFile_len = document.getElementById("Dlg_filename").files.length;
		for (var file_i = 0; file_i < uploadedFile_len; file_i++) {
			fd.append("Dlg_filename", document.getElementById('Dlg_filename').files[file_i]);
			uploadFile_size = document.getElementById('Dlg_filename').files[file_i].size;
		}
		var filepath = document.getElementById('Dlg_filename').value;
		var filenameWithExtension = filepath.replace(/^.*[\\\/]/, '');
		fd.append("filename", filenameWithExtension);

		xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if(!testalready_exists.test(this.responseText.toString()))
			{
				var output_arr = this.responseText.toString().split("\n");				
				parent.ifm_link.contentWindow.document.getElementById("qualify_link").style.display = "block";
				Output_StringPath = output_arr[0];
				localStorage.setItem("Output_StringPath",Output_StringPath);									
				document.getElementById('Txt_reportname').disabled = false;
				document.getElementById('Btn_upload').disabled = false;
				document.getElementById('Dlg_filename').disabled = false;
				document.getElementById('Btn_Qualify').disabled = true;
				//CallLogstashFile(Output_StringPath.trim());
				var string_path_arr = Output_StringPath.toString().split("\\");
				localStorage.setItem("log_type",string_path_arr[string_path_arr.length - 3].toLowerCase());
				if((string_path_arr[string_path_arr.length - 3] == "Others")||(string_path_arr[string_path_arr.length - 3] == "Siebel")||(string_path_arr[string_path_arr.length - 3] == "DB"))
				{
					parent.document.getElementById('top').style.display = 'none';
					alert("Uploaded log file is not qualified for any of the standard log type, Support team will get back to you shortly");
				}
				else if(string_path_arr[string_path_arr.length - 3] == "Trash")
				{
					parent.document.getElementById('top').style.display = 'none';
					alert("Uploaded log file is found to be invalid file");
				}
				else{
				if(string_path_arr[string_path_arr.length - 3] == "SAP")
				{
					issapLog = true;
					localStorage.setItem("issapLog", issapLog);
					isappLog = false;
					localStorage.setItem("isappLog", isappLog);	
					isgoogleLog = false;
					localStorage.setItem("isgoogleLog", isgoogleLog);
					SAP_NFR();
				}
				else if(string_path_arr[string_path_arr.length - 3] == "App")
				{
					isappLog = true;
					localStorage.setItem("isappLog", isappLog);
					issapLog = false;
					localStorage.setItem("issapLog", issapLog);
					isgoogleLog = false;
					localStorage.setItem("isgoogleLog", isgoogleLog);
					App_log();
				}
				else
				{
					issapLog = false;
					localStorage.setItem("issapLog", issapLog);
					isappLog = false;
					localStorage.setItem("isappLog", isappLog);
				}
				var resp = output_arr[1];
				// List of fields from given Logs
				var field_data_arr = resp.split("'");
				setTimeout(myTimer, 5000);
				function myTimer() {
					if (!issapLog)		
					{
					//parent.ifm_link.contentWindow.document.getElementById("qualify_link").style.display = "none";
					parent.document.getElementById('top').style.display = 'none';
					document.getElementById("Div_NewQual_Output").style.display = "block";				 
					//var divlink = parent.ifm_link.contentWindow.document.getElementById("Div_link");					
					var divlink = parent.document.getElementById("ifm_link").contentWindow.document.getElementById("Div_link");
					for(var div_i=divlink.childNodes.length-1; div_i > 3; div_i--)
					{
						divlink.removeChild(divlink.childNodes[div_i]);
					}
					for(var fs_i=fs_new.childNodes.length-1; fs_i > 3; fs_i--)
					{
						fs_new.removeChild(fs_new.childNodes[fs_i]);
					}
					for (var str_i = 1; str_i < string_path_arr.length; str_i = str_i+1) {
						// usage pattern check 
							if(field_data_arr[str_i] == "1")
							{
								if(string_path_arr[string_path_arr.length - 3] == "Consumer")
								{
									isgoogleLog = true;
									localStorage.setItem("isgoogleLog", isgoogleLog);
								}
								else
								{
									isgoogleLog = false;
									localStorage.setItem("isgoogleLog", isgoogleLog);
								}							
								
								var ua_cb = document.createElement('input');
								ua_cb.type = 'checkbox';
								ua_cb.checked = true;
								ua_cb.style.marginLeft = "150px";
								fs_new.appendChild(ua_cb);
								var ua_aTag = document.createElement('a');
								ua_aTag.setAttribute('href',"javascript:usagepattern_chart();");
								ua_aTag.innerHTML = "Usage Analysis\n\n";						
								ua_aTag.style.textDecoration = "underline";
								fs_new.appendChild(ua_aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var ua_aTag_link = document.createElement('a');
								ua_aTag_link.setAttribute('href',"javascript:usagepattern_chart();");
								ua_aTag_link.innerHTML = "Usage Analysis <br/><br/>";						
								ua_aTag_link.style.textDecoration = "underline"; 
								divlink.appendChild(ua_aTag_link);
							}
							
							// Data Combination				
							if(field_data_arr[str_i] == "2")
							{						
								var dc_cb = document.createElement('input');
								dc_cb.type = 'checkbox';
								dc_cb.checked = true;
								dc_cb.style.marginLeft = "150px";
								fs_new.appendChild(dc_cb);
								var dc_aTag = document.createElement('a');
								dc_aTag.setAttribute('href',"javascript:DataCombination();");
								dc_aTag.innerHTML = "Data Combination\n";						
								dc_aTag.style.textDecoration = "underline"; 
								fs_new.appendChild(dc_aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var dc_aTag_link = document.createElement('a');
								dc_aTag_link.setAttribute('href',"javascript:DataCombination();");
								dc_aTag_link.innerHTML = "Data Combination <br/><br/>";						
								dc_aTag_link.style.textDecoration = "underline";
								divlink.appendChild(dc_aTag_link);
							}
							
							// Failure Analysis
							if(field_data_arr[str_i] == "3")
							{
								var fa_cb = document.createElement('input');
								fa_cb.type = 'checkbox';
								fa_cb.checked = true;
								fa_cb.style.marginLeft = "150px";
								fs_new.appendChild(fa_cb);
								var fa_aTag = document.createElement('a');
								fa_aTag.setAttribute('href',"javascript:FailureAnalysis();");
								fa_aTag.innerHTML = "Failure Analysis";						
								fa_aTag.style.textDecoration = "underline"; 
								fs_new.appendChild(fa_aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var fa_aTag_link = document.createElement('a');
								fa_aTag_link.setAttribute('href',"javascript:FailureAnalysis();");
								fa_aTag_link.innerHTML = "Failure Analysis<br/><br/>";						
								fa_aTag_link.style.textDecoration = "underline";
								divlink.appendChild(fa_aTag_link);
							}

							// Business Flow Transaction check 
							if(field_data_arr[str_i] == "4")
							{							
								var bt_cb = document.createElement('input');
								bt_cb.type = 'checkbox';
								bt_cb.checked = true;
								bt_cb.style.marginLeft = "150px";
								fs_new.appendChild(bt_cb);
								var bt_aTag = document.createElement('a');
								bt_aTag.setAttribute('href',"javascript:BusinessFlowTran();");
								bt_aTag.innerHTML = "Business Flow Transaction";						
								bt_aTag.style.textDecoration = "underline"; 
								fs_new.appendChild(bt_aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var bt_aTag_link = document.createElement('a');
								bt_aTag_link.setAttribute('href',"javascript:BusinessFlowTran();");
								bt_aTag_link.innerHTML = "Business Flow Transaction<br/><br/>";						
								bt_aTag_link.style.textDecoration = "underline";
								divlink.appendChild(bt_aTag_link);
							}
							
							// common Anomaly					
							if(field_data_arr[str_i] == "5")
							{						
								var ca_cb = document.createElement('input');
								ca_cb.type = 'checkbox';
								ca_cb.checked = true;
								ca_cb.style.marginLeft = "150px";
								fs_new.appendChild(ca_cb);
								var ca_aTag = document.createElement('a');
								ca_aTag.setAttribute('href',"javascript:getCommonAnomalyChart();");
								ca_aTag.innerHTML = "Common Anomaly\n";						
								ca_aTag.style.textDecoration = "underline"; 
								fs_new.appendChild(ca_aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var ca_aTag_link = document.createElement('a');
								ca_aTag_link.setAttribute('href',"javascript:getCommonAnomalyChart();");
								ca_aTag_link.innerHTML = "Common Anomaly<br/><br/>";						
								ca_aTag_link.style.textDecoration = "underline";
								divlink.appendChild(ca_aTag_link);
							}
							
							// Common RCA
							if(field_data_arr[str_i] == "6")
							{
								var cr_cb = document.createElement('input');
								cr_cb.type = 'checkbox';
								cr_cb.checked = true;
								cr_cb.style.marginLeft = "150px";
								fs_new.appendChild(cr_cb);
								var aTag = document.createElement('a');
								aTag.setAttribute('href',"javascript:getCommonRCAChart();");
								aTag.innerHTML = "Common RCA\n";						
								aTag.style.textDecoration = "underline"; 
								fs_new.appendChild(aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var aTag1 = document.createElement('a');
								aTag1.setAttribute('href',"javascript:getCommonRCAChart();");
								aTag1.innerHTML = "Common RCA<br/><br/>";						
								aTag1.style.textDecoration = "underline";
								divlink.appendChild(aTag1);
							}
							
							// Top SQLs					
							if(field_data_arr[str_i] == "8")
							{						
								var ts_cb = document.createElement('input');
								ts_cb.type = 'checkbox';
								ts_cb.checked = true;
								ts_cb.style.marginLeft = "150px";
								fs_new.appendChild(ts_cb);
								var ca_aTag = document.createElement('a');
								ca_aTag.setAttribute('href',"javascript:getTopSQLs();");
								ca_aTag.innerHTML = "Top SQLs\n";						
								ca_aTag.style.textDecoration = "underline"; 
								fs_new.appendChild(ca_aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var ca_aTag_link = document.createElement('a');
								ca_aTag_link.setAttribute('href',"javascript:getTopSQLs();");
								ca_aTag_link.innerHTML = "Top SQLs<br/><br/>";						
								ca_aTag_link.style.textDecoration = "underline"; 
								divlink.appendChild(ca_aTag_link);
							}
							
							// All SQLs				
							if(field_data_arr[str_i] == "9")
							{						
								var as_cb = document.createElement('input');
								as_cb.type = 'checkbox';
								as_cb.checked = true;
								as_cb.style.marginLeft = "150px";
								fs_new.appendChild(as_cb);
								var ca_aTag = document.createElement('a');
								ca_aTag.setAttribute('href',"javascript:getAllSQLs();");
								ca_aTag.innerHTML = "All SQLs\n";						
								ca_aTag.style.textDecoration = "underline"; 
								fs_new.appendChild(ca_aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var ca_aTag_link = document.createElement('a');
								ca_aTag_link.setAttribute('href',"javascript:getAllSQLs();");
								ca_aTag_link.innerHTML = "All SQLs<br/><br/>";						
								ca_aTag_link.style.textDecoration = "underline"; 
								divlink.appendChild(ca_aTag_link);
							}
							
							// Memory Analysis
							if(field_data_arr[str_i] == "12")
							{
								var ma_cb = document.createElement('input');
								ma_cb.type = 'checkbox';
								ma_cb.checked = true;
								ma_cb.style.marginLeft = "150px";
								fs_new.appendChild(ma_cb);
								var ma_aTag = document.createElement('a');
								ma_aTag.setAttribute('href',"javascript:MemoryAnalysis();");
								ma_aTag.innerHTML = "Memory Analysis";						
								ma_aTag.style.textDecoration = "underline"; 
								fs_new.appendChild(ma_aTag);
								var space3 = document.createElement('br');
								fs_new.appendChild(space3);
								var space4 = document.createElement('br');
								fs_new.appendChild(space4);
								
								var ma_aTag_link = document.createElement('a');
								ma_aTag_link.setAttribute('href',"javascript:MemoryAnalysis();");
								ma_aTag_link.innerHTML = "Memory Analysis<br/><br/>";						
								ma_aTag_link.style.textDecoration = "underline";
								divlink.appendChild(ma_aTag_link);
							}
							
						}
					}					
				}			
				}
			}
			else if(this.responseText.toString().indexOf('Please') > -1)
			{
				alert(this.responseText.toString());
				parent.document.getElementById('top').style.display = 'none';
			}
			else
			{
				alert("reportname already present");
				parent.document.getElementById('top').style.display = 'none';
			}
	   }
	   else if (this.readyState == 4 && this.status == 208) {
				alert("Fail to upload");
				parent.document.getElementById('top').style.display = 'none';
		}
		};
		xhttp.open("POST", "../cgi-bin/qualify.py?user="+localStorage.getItem('username')+"&logname="+reportname+"", true);
		xhttp.send(fd);
	}
}