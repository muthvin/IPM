/*************** Welcome Page **********************/

// function to call on click New qualifier page
// function create as part of story ST05
function callNewQualifierPage()
{
	window.location = 'Lapam.html';
	localStorage.setItem("QualContent","New");
	parent.ifm_logout.contentWindow.document.getElementById("href_home").style.display = 'block';
}

// function to call on click existing qualifier page
// function create as part of story ST06
function callExistingQualifierPage()
{
	window.location = 'Lapam.html';
	localStorage.setItem("QualContent","Existing");
	parent.ifm_logout.contentWindow.document.getElementById("href_home").style.display = 'block';
}