#######################################################################
#Application : LAPAM
#Build : v0
#Desc: Check whether the log type is DB if then Upload to the DB folder
#Created by : Karpagam
#Modified by: Karpagam
#Date of Modification:8/6/2018
#Reason for modification:Header Added
#code developed as part of story ST008 - Qualify
########################################################################

import shutil,os,re

def db_check(logpath_file,DATA_PATH,report_name,loglines):
    Destination = DATA_PATH
    """iis = get_iis_fields(logpath_file)
    apache = get_apache_fields(logpath_file)
    print(apache)"""
    for line in loglines:
        sql_match = re.match(".*SQL_EXEC_ID.*",line)
        oracle_match = re.match(".*AWR Report for DB\:.*",line)
        if sql_match:
            DATA_PATH_DB = DATA_PATH+"MsSQL\\"+report_name
            if not os.path.exists(DATA_PATH_DB):
                os.mkdir(DATA_PATH_DB)
            files = [f for f in os.listdir(DATA_PATH) if os.path.isfile(os.path.join(DATA_PATH, f))]
            shutil.move(os.path.join(DATA_PATH, files[0]), os.path.join(DATA_PATH_DB, files[0]))
            logpath_file = DATA_PATH_DB+"\\"+files[0]
            break
        elif oracle_match:
            DATA_PATH_DB = DATA_PATH+"Oracle\\"+report_name
            if not os.path.exists(DATA_PATH_DB):
                os.mkdir(DATA_PATH_DB)
            files = [f for f in os.listdir(DATA_PATH) if os.path.isfile(os.path.join(DATA_PATH, f))]
            shutil.move(os.path.join(DATA_PATH, files[0]), os.path.join(DATA_PATH_DB, files[0]))
            logpath_file = DATA_PATH_DB+"\\"+files[0]
            break
    return logpath_file
