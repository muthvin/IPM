#######################################################################
#Application : LAPAM
#Build : v0
#Desc: Check the logtype is Device then upload to the log into the Device folder 
#Created by : Karpagam
#Modified by: Muthu
#Date of Modification:8/6/2018
#Reason for modification:Header Added
#code developed as part of story ST008 - Qualify
########################################################################

import shutil,os
from getWSFields import get_iis_fields, get_apache_fields, get_google_fields

def device_check(logpath_file,DATA_PATH,report_name):
    Destination = DATA_PATH
    """iis = get_iis_fields(logpath_file)
    apache = get_apache_fields(logpath_file)
    print(apache)"""
    if get_google_fields(logpath_file):
        DATA_PATH_google = DATA_PATH+"Consumer\\"+report_name
        if not os.path.exists(DATA_PATH_google):
            os.mkdir(DATA_PATH_google)
        files = [f for f in os.listdir(DATA_PATH) if os.path.isfile(os.path.join(DATA_PATH, f))]
        shutil.move(os.path.join(DATA_PATH, files[0]), os.path.join(DATA_PATH_google, files[0]))
        logpath_file = DATA_PATH_google+"\\"+files[0]
    return logpath_file
