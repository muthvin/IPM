#######################################################################
#Application : CBOL
#Build : v3
#Desc: Get the TestName form DB for dropdown
#Created by : Rajkumar
#Modified by : Muthu
#Date of Modification:20/11/2018
#code developed as part of story ST006 - Existing
########################################################################

import cgi, cgitb 
import cgitb; cgitb.enable()
import pyodbc
import configparser

parser = configparser.ConfigParser() 
parser.read("C:\\CBOL\\Config\\configfile.config")
DSN_NAME = parser.get('Upload','DSN_NAME')

form = cgi.FieldStorage()
prj_id = form.getvalue("prj_id")

#fetch test values from quaifier table
def get_values(con,prj_name):
        query = 'SELECT `Report_Name` FROM log_info WHERE `PRJ_ID` = "'+str(prj_id)+'";'
        con.execute(query)
        res = con.fetchall()
        return res	

#database connection
def create_connection(prj_id):
	db1 = pyodbc.connect("DSN="+DSN_NAME)
	cur = db1.cursor()
	ret = get_values(cur,prj_id)
	return ret	

ret = create_connection(prj_id)
print ("Content-type: text/html \n\n");
print(ret)


	
	
