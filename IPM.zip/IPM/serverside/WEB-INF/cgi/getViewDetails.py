#######################################################################
#Application : CBOL
#Build : v0
#Desc: Copy the csv file from old reports to Reports folder to view
#Created by : Rajkumar
#Modified by: Muthu
#Date of Modification:20/11/2018
#Reason for modification:DSN Input variable changed
#code developed as part of story ST006 - Existing
########################################################################

import cgi, cgitb, os
import cgitb; cgitb.enable()
from shutil import copy
import pyodbc
import configparser

parser = configparser.ConfigParser() 
parser.read("C:\\CBOL\\Config\\configfile.config")
DSN_NAME = parser.get('Upload','DSN_NAME')

form = cgi.FieldStorage()
report_name = form.getvalue("report_name")
userid = form.getvalue('userid').strip()
prjid = form.getvalue('prjid').strip()

#fetch test values from log_info table
def get_values(con,prj_name):
        query = 'select log_imp_ids,LOG_TYPE from log_info where LOG_NAME = "'+str(report_name)+'";'
        #print(query)
        con.execute(query)
        res = con.fetchall()
        return res

#database connection
def create_connection(report_name):
	db1 = pyodbc.connect("DSN="+DSN_NAME)
	cur = db1.cursor()
	ret = get_values(cur,report_name)
	return ret	

ret = create_connection(report_name)
print ("Content-type: text/html \n\n");
print(ret)
folder_name = userid + "_" + prjid + "_" + report_name
src = "C:\\CBOL\\DataLake\\Reports\\" + folder_name + "\\"

# usagefilename = src + folder_name + "_usageptn.csv"
# failurefilename = src + folder_name + "_failptn.csv"
# dcjsonfilename = src + folder_name + "_datacbn.json"
# dcfilename = src + folder_name + "_datacbn.csv"
# workstreamfilename = src + folder_name + "_RCAWorkStream.csv"
# layersfilename = src + folder_name + "_RCALayers.csv"
# if os.path.exists(usagefilename):
        # copy(usagefilename, "../../../html/Reports/")
# if os.path.exists(failurefilename):
        # copy(failurefilename, "../../../html/Reports/")
# if os.path.exists(dcfilename):
        # copy(dcfilename, "../../../html/Reports/")
# if os.path.exists(dcjsonfilename):
        # copy(dcjsonfilename, "../../../html/Reports/")
# if os.path.exists(workstreamfilename):
	# copy(workstreamfilename, "../../../html/Reports/")
# if os.path.exists(layersfilename):
	# copy(layersfilename, "../../../html/Reports/")


	
	
