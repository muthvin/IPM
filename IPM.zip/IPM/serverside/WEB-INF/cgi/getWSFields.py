#######################################################################
#Application : LAPAM
#Build : v0
#Desc: Get the possible fields for log 
#Created by : Karpagam
#Modified by: Karpagam
#Date of Modification:8/6/2018
#Reason for modification:Header Added
# function created as part of ST008-qualify
########################################################################

import os
import re

return_string = ""
# function created as part of ST008-qualify
# get IIS log fields 
def get_iis_fields(logpath):
    return_string =""
    l = [] # a list to hold a <dict> for each line in the IIS log file
    fp = open(logpath,encoding="utf-8", errors='ignore')
    for line in fp:
        if "#Fields" in line:
            line = line.strip()
            fields = line.split()
            l.extend(line.split())
            #l.append(fields)
    l = set(l)
    try:
        l.remove("#Fields:")
    except:
        pass
    
    if "cs-uri-stem" in l:
        return_string = "1"
    else:
        return_string = "0"
    if "data" in l:
        return_string = return_string+"1"
    else:
        return_string =  return_string+"0"
    if "sc-status" in l:
        return_string = return_string+"1"
    else:
        return_string = return_string+"0"
    if "business" in l:
        return_string =  return_string+"1"
    else:
        return_string =  return_string+"0"
    if "predictive" in l:
        return_string = return_string+"1"
    else:
        return_string =  return_string+"0"
      
    return return_string.strip()

# get apache fields from logs
def get_apache_fields(input_dir):
    return_string =""
    #parts for matching the pattern in a line
    parts = [
        r'(?P<host>\S+)',                   # host %h
        r'\S+',                             # indent %l (unused)
        r'(?P<user>\S+)',                   # user %u
        r'\[(?P<time>.+)\]',                # time %t
        r'"(?P<request>.+)"',               # request "%r"
        r'(?P<response>[0-9]+)',              # status %>s
        r'(?P<size>\S+)',                   # size %b (careful, can be '-')
        r'"(?P<referer>.*)"',               # referer "%{Referer}i"
        r'"(?P<agent>.*)"',                 # user agent "%{User-agent}i"
    ]
    pattern = re.compile(r'\s+'.join(parts)+r'\s*\Z')
    l = []
    req = []
    fp = open(input_dir,encoding="utf-8")
    i = 1
    for line in fp:
        if i == 50:
            break
        else:
            m = pattern.match(line)
            res = m.groupdict()
            res = {k:v for k,v in res.items() if v != '-'}
            req.extend(res['request'])
            l.extend(res.keys())
            i = i+1
    l = set(l)
    if "request" in l:
        return_string = "1"
    else:
        return_string = "1"
    if "?" in req:
        return_string =  return_string+"1"
    else:
        return_string =  return_string+"0"
    if "response" in l:
        return_string =  return_string+"1"
    else:
        return_string = return_string+"0"
    if "business" in l:
        return_string = return_string+"1"
    else:
        return_string = return_string+"0"
    if "predictive" in l:
        return_string = return_string+"1"
    else:
        return_string = return_string+"0"
      
    return return_string.strip()

# get apache fields from logs
def get_google_fields(input_dir):
    return_string = ""
    date_format = "%Y%m%d %H:%M:%S.%f"
    l = []
    fp = open(input_dir,encoding="utf-8")
    i = 1
    for line in fp:
        pattern = re.match(r'(.*?) [A-Z]{1}.*',line)
        if pattern:
            return "10010"
            break
