#######################################################################
#Application : LAPAM
#Build : v0
#Desc: qualify the logtype
#Created by : Karpagam
#Modified by: Muthu
#Date of Modification:21/11/2018
#Reason for modification:Add 
#code developed as part of story ST008 - Qualify
########################################################################

import os,shutil
import zipfile
import cgi, cgitb
from itertools import islice
import re,xlrd
import pyodbc
import configparser
import datetime
from dateutil.parser import parse
from web import web_check
from device import device_check
from db import db_check
from sapFields import issapfields
_sample_line = 10
imp_name=[]

#fetch the upload path from config
parser = configparser.ConfigParser() 
parser.read("C:\\CBOL\\Config\\configfile.config")
DATA_PATH = parser.get('Upload','upload_path')
DSN_NAME = parser.get('Upload','DSN_NAME')

#insert upload details into log_info table
def insert_uploadlogentry(username, userid, prjid, report_name):
    db1 = pyodbc.connect("DSN="+DSN_NAME)
    cursor = db1.cursor()
    query = """INSERT INTO log_info (`USER_ID`, `PRJ_ID`, `REPORT_NAME`, `LOG_TYPE`, `LOG_IMP_IDS`, `CREATION_DATE`)
                VALUES ('%s','%s','%s','','',now());"""
    cursor.execute(query %(userid,prjid,report_name))
    db1.commit()


# function to insert test in DB
def insert_db(report_name, userid, prjid,output_string):
    db1 = pyodbc.connect("DSN="+DSN_NAME)
    cursor = db1.cursor()
    logtype = output_string.split('\\')[-3]
    #query = ""
    query = """INSERT INTO log_info (`USER_ID`, `PRJ_ID`, `REPORT_NAME`, `LOG_TYPE`, `LOG_IMP_IDS`, `CREATION_DATE`)
                VALUES ('%s','%s','%s','%s','%s',now());"""
    #cursor.execute(query %(userid,prjid,report_name))
##    if(logtype == "SAP"):
##        query = "update log_info set log_type = '"+logtype+"', log_imp_ids=(select log_imp_ids from log_imp_info where log_type='"+logtype+"') where USER_ID='"+userid+"' and PRJ_ID='"+prjid+"' and REPORT_NAME='"+report_name+"'"
##    else:
##        query = "update log_info set log_type = '"+logtype+"', log_imp_ids=(select log_imp_ids from log_imp_info where log_type='"+logtype+"') where USER_ID='"+userid+"' and PRJ_ID='"+prjid+"' and REPORT_NAME='"+report_name+"'"
    getActualFields = "select log_imp_ids from log_imp_info where LOG_TYPE='"+logtype+"';"
    try:
        imp_id_res = cursor.execute(getActualFields).fetchone()
        cursor.execute(query %(userid,prjid,report_name,logtype,imp_id_res[0]))
        db1.commit()
        imp_ids = imp_id_res[0].split(":")
        for imp_i in imp_ids:
            imp_name.append(imp_i);
    except:
        value = "failure"

# function to insert test in DB
def delete_trashfile(report_name, userid, prjid, output_string):
    db1 = pyodbc.connect("DSN="+DSN_NAME)
    cursor = db1.cursor()
    logtype = output_string.split('\\')[-3]
    query = ""
    if(logtype == "Trash"):
        query = "delete from log_info where USER_ID='"+userid+"' and PRJ_ID='"+prjid+"' and REPORT_NAME='"+report_name+"';"
        cursor.execute(query)
        db1.commit()
        
def qualify_log(HOME_PATH,_sample_line,report_name,userid,prjid,filename):
    File_path = HOME_PATH + "Cache\\" + userid + "_"+prjid+"_"+report_name+"\\"
    files = [f for f in os.listdir(File_path) if os.path.isfile(os.path.join(File_path, f))]
    logpath_file = File_path + filename
    loglines = []
    if filename.endswith((".xlsx")):
        sheet_num = 0
        wb=xlrd.open_workbook(logpath_file)
        sheet=wb.sheet_by_index(sheet_num)
        loglines = iter_rows(sheet)
    else:
        fp = open(logpath_file,encoding='utf8', errors='ignore')
        head = fp.readlines()
        fp.close()
        loglines = head[:10]
    return find_log_type(loglines,logpath_file,HOME_PATH,report_name,userid,prjid) 

def find_log_type(loglines,logpath_file,HOME_PATH,report_name,userid,prjid):
    flag = 0
    for line in loglines:
        line = line.strip()
        line = re.sub(r'[\n\r]','',line)
        web = re.match(".*(?:GET|POST).*",line)
        app = re.match(".*(?:INFO|DEBUG|Info$|Debug$).*",line)
        Device = re.match(".*(?:Add to expect_queue|Add to log_writer_queue).*",line)
        DB = re.match(".*Report for DB\:.*",line)
        SAP = re.match(".*\,Transaction or jobname\,.*\,User\,.*\,CPU time.*\,DB req.*",line)
        siebel = re.match(".*\/siebsrvr\/.*",line)
        other = re.match("(\d+.*?)\s.*",line)
        if app:
            flag = 1
            DATA_PATH = HOME_PATH + "App\\" + userid + "_"+prjid+"_"+report_name
            file = os.path.basename(logpath_file)
            if not os.path.exists(DATA_PATH):
                os.mkdir(DATA_PATH)
            shutil.move(os.path.join(HOME_PATH + "Cache\\" + userid + "_"+prjid+"_"+report_name+"\\", file), os.path.join(DATA_PATH, file))
            logpath_file = DATA_PATH+"\\"+file
            return(logpath_file)
            break
        elif web:
            flag = 1
            DATA_PATH = HOME_PATH + "Web"
            if not os.path.exists(DATA_PATH):
                os.mkdir(DATA_PATH)
            shutil.move(logpath_file, DATA_PATH)
            DATA_PATH = DATA_PATH + "\\"
            files = [f for f in os.listdir(DATA_PATH) if os.path.isfile(os.path.join(DATA_PATH, f))]
            logpath_file = DATA_PATH+files[0]
            pathname = userid + "_"+prjid+"_"+report_name;
            web_path = web_check(logpath_file,DATA_PATH,pathname)
            return(web_path)
            break
        elif Device:
            flag = 1
            DATA_PATH = HOME_PATH + "Device"
            if not os.path.exists(DATA_PATH):
                os.mkdir(DATA_PATH)
            shutil.move(logpath_file, DATA_PATH)
            DATA_PATH = DATA_PATH + "\\"
            files = [f for f in os.listdir(DATA_PATH) if os.path.isfile(os.path.join(DATA_PATH, f))]
            logpath_file = DATA_PATH+files[0]
            pathname = userid + "_"+prjid+"_"+report_name;
            device_path = device_check(logpath_file,DATA_PATH,pathname)
            return (device_path)
            break
        elif DB:
            flag = 1
            DATA_PATH = HOME_PATH + "DB"
            if not os.path.exists(DATA_PATH):
                    os.mkdir(DATA_PATH)
            shutil.move(logpath_file, DATA_PATH)
            DATA_PATH = DATA_PATH + "\\"
            files = [f for f in os.listdir(DATA_PATH) if os.path.isfile(os.path.join(DATA_PATH, f))]
            logpath_file = DATA_PATH+files[0]
            pathname = userid + "_"+prjid+"_"+report_name;
            db_path = db_check(logpath_file,DATA_PATH,pathname,loglines)
            return(db_path)
            break
        elif SAP:
            flag = 1
            fields_bool = issapfields(line)
            if fields_bool:
                DATA_PATH = HOME_PATH + "SAP\\" + userid + "_"+prjid+"_"+report_name
                file = os.path.basename(logpath_file)
                if not os.path.exists(DATA_PATH):
                    os.mkdir(DATA_PATH)
                shutil.move(os.path.join(HOME_PATH + "Cache\\" + userid + "_"+prjid+"_"+report_name+"\\", file), os.path.join(DATA_PATH, file))
                logpath_file = DATA_PATH+"\\"+file
                return(logpath_file)
            else:
                return "Please Check the Log file Fields"
            break
        elif siebel:
            flag = 1
            DATA_PATH = HOME_PATH + "Siebel\\" + userid + "_"+prjid+"_"+report_name
            file = os.path.basename(logpath_file)
            if not os.path.exists(DATA_PATH):
                os.mkdir(DATA_PATH)
            shutil.move(os.path.join(HOME_PATH + "Cache\\" + userid + "_"+prjid+"_"+report_name+"\\", file), os.path.join(DATA_PATH, file))
            logpath_file = DATA_PATH+"\\"+file
            return(logpath_file)
            break

        elif other:
            flag = 1
            other_check = ""
            try: 
                parse(other.group(1))
                other_check= 'True'
            except ValueError:
                other_check ='False'
            if other_check == "True":
                DATA_PATH = HOME_PATH + "Others\\" + userid + "_"+prjid+"_"+report_name
                file = os.path.basename(logpath_file)
                if not os.path.exists(DATA_PATH):
                    os.mkdir(DATA_PATH)
                shutil.move(os.path.join(HOME_PATH + "Cache\\" + userid + "_"+ prjid+"_"+report_name+"\\", file), os.path.join(DATA_PATH, file))
                logpath_file = DATA_PATH+"\\"+file
                return (logpath_file)
                break
    
    if flag == 0:
        DATA_PATH = HOME_PATH + "Trash\\" + userid + "_"+prjid+"_"+report_name
        file = os.path.basename(logpath_file)
        if os.path.exists(DATA_PATH):
            os.remove(DATA_PATH)
        if not os.path.exists(DATA_PATH):
            os.mkdir(DATA_PATH)
        shutil.move(os.path.join(HOME_PATH + "Cache\\" + userid + "_"+prjid+"_"+report_name+"\\", file), os.path.join(DATA_PATH, file))
        logpath_file = DATA_PATH+"\\"+file
        return logpath_file

def iter_rows(sheet):
    top_10 = []
    i = 0
    while(i< 10):
        row = sheet.row(i)
        rows = []
        for val in row:
            rows.append(str(val.value))
        row_line = ",".join(rows)
        top_10.append(row_line)
        i = i+1
    return top_10

           
if __name__ == "__main__":
##    report_name = "sap3_11"
##    fn = "Sample1.xlsx"
##    userid = "1"
##    prjid = "1"
##    filename = "Sample1.xlsx"
##    uploaded_path = "C:\\CBOL\\DataLake\\Logs\\Cache\\1_1_test_nfr3"
    print("Content-type: text/html \n");
    form = cgi.FieldStorage()
    filename = form.getvalue('filename').strip()
    userid = form.getvalue('userid').strip()
    prjid = form.getvalue('prjid').strip()
    report_name = form.getvalue('Txt_reportname')
    username = form.getvalue('username').strip()
    report_name = report_name.strip().lower()
    uploaded_path = form.getvalue('uploaded_path')

    #logtype = qualify_log(uploaded_path,_sample_line,report_name,fn)
    output_string = qualify_log(DATA_PATH,_sample_line,report_name, userid, prjid, filename)
    print(output_string)
    if "\\" in output_string: 
        shutil.rmtree(DATA_PATH + "Cache\\" + userid + "_"+prjid+"_"+report_name+"\\")
        #insert_uploadlogentry(username, userid, prjid, report_name)
        insert_db(report_name, userid, prjid, output_string)
        #delete_trashfile(report_name, userid, prjid, output_string)
        print(imp_name)
