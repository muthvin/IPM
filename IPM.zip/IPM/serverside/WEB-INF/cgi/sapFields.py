#code developed as part of story ST008 - Qualify

SAP_HEADLIST = ["Started","Transaction or jobname","Response","Wait time","CPU time","DB req.","Processing","Load time","Roll (i+w)","Enqueue","GUI time","User","Typ","Time in","Generating","Server"]


def issapfields(log_header):
    logHead_list = log_header.split(",")
    logHead_list = [s for s in logHead_list if s != 'None']
    for val in SAP_HEADLIST:
        if val in logHead_list:
            continue
        else:
            return False
            break
    return True
if __name__ == "__main__":
    #test_name = "SAP_jul126"
    #fn = "Stad_Philips.xlsx"
    head = "None,None,Started,None,Server,None,None,Step,None,Typ,None,Transaction or jobname,None,None,None,User,None,None,None,None,Response,Time in,Wait time,CPU time,DB req.,VMC elapsed,Memory,Transfered,Phys. DB,Processing,Load time,Generating,Roll (i+w),Enqueue,Load time,Load time,Load time,Roll ins,Roll outs,Roll in,Roll out,Roll wait,GUI time,DB requests,DB rows,Buffer req.,Avg. time/row,Dir. read,Dir. read,Dir. read,Dir. read,Seq. read,Seq. read,Seq. read,Seq. read,Seq. read avg,Update,Update,Update,Update,Update  avg.,Insert,Insert,Insert,Insert,Insert  avg.,No. DB pro-,DB proc. cal,Tcode,CUA ref.,CUA internal,Transaction ID,Application"
    value = issapfields(head)
    print(value)
