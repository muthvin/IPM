#######################################################################
#Application : CBOL
#Build : v0
#Desc: Upload the log 
#Created by : Karpagam
#Modified by: Muthu
#Date of Modification:21/11/2018
#Reason for modification:DSN Input variable changed
#code developed as part of story ST007 - Upload
########################################################################

import os
import zipfile
import cgi, cgitb
from itertools import islice
import re
import pyodbc,datetime
output_string = ""
value = ""
imp_name=[]
import configparser

#fetch the upload path from config
parser = configparser.ConfigParser() 
parser.read("C:\\CBOL\\Config\\configfile.config")
DATA_PATH = parser.get('Upload','upload_path')
DSN_NAME = parser.get('Upload','DSN_NAME')

# check given report name alerady exists in database
def is_report_existing(userid, prjid, report_name):
    query = 'select REPORT_NAME FROM log_info WHERE REPORT_NAME = "'+report_name+'" and user_id="'+userid+'" and prj_id="'+prjid+'";'
    db1 = pyodbc.connect("DSN="+DSN_NAME)
    cursor = db1.cursor()
    res = cursor.execute(query).fetchall()
    if len(res) == 0:
        return True
    return False    

# upload log file into data folder
def run_upload(fileitem,report_name):
    fn = os.path.basename(fileitem.filename)
    dir_path = DATA_PATH + "Cache\\" + userid + "_"+prjid+"_"+report_name
    if not os.path.exists(dir_path):
        os.mkdir(dir_path)
    full_dir_path = dir_path + "\\"

    try:
        if fn.endswith(".zip"):
            zip_handler = zipfile.ZipFile(fileitem.file, "r")
            zip_handler.extractall(full_dir_path)
            zip_handler.close()
            print(full_dir_path)
        else:
            if fn.endswith((".log",".txt",".xlsx",".csv")):
                g = open(full_dir_path + fn, 'wb').write(fileitem.file.read())
                print(full_dir_path)
                return "FUP 1 File uploaded successfully"
            else:
                return "FUP 0,Please upload the valid file"
                exit(1)

    except Exception as e:
        print(e)
        return 'FUP 0,Unexpected error:{exception}'.format(exception=e)
        exit(1)

# main function
if __name__ == "__main__":
       print("Content-type: text/html \n");
       try:
           form = cgi.FieldStorage()
           fileitem = form['Dlg_filename']
           userid = form.getvalue('userid').strip()
           prjid = form.getvalue('prjid').strip()
           report_name = form.getvalue('Txt_reportname')
           report_name = report_name.strip().lower()
           if is_report_existing(userid, prjid, report_name):
               run_upload(fileitem,report_name)
           else:
               print("TAP 0, Log name already exists")
       except Exception as e:
           print (e)
