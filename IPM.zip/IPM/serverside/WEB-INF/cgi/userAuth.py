#######################################################################
#Application : CBOL
#Build : v0
#Desc: Check the user authentication 
#Created by : Karpagam
#Modified by: Muthu
#Date of Modification:20/11/2018
#Reason for modification:DSN Input variable changed
#code developed as part of story ST003 - Login
########################################################################

import cgi, cgitb 
import cgitb; cgitb.enable()
import pyodbc
import configparser

parser = configparser.ConfigParser() 
parser.read("C:\\CBOL\\Config\\configfile.config")
DSN_NAME = parser.get('Upload','DSN_NAME')

# database connection 
def create_connection():
    con = pyodbc.connect("DSN="+DSN_NAME)
    cur = con.cursor()
    return cur

# validate the given user credential
def authenticate_user(conn,user,passwd):
    query = 'SELECT USER_ID from info where USER_NAME="'+str(user)+'" and Password = "'+str(passwd)+'" and Status=1;'
    res = conn.execute(query)
    if len(conn.fetchall()) != 0:
        return True
    return False

# main function
if __name__ == "__main__":
    form = cgi.FieldStorage()
    user = form.getvalue('Txt_Username')
    passwd = form.getvalue('Txt_Password')
    conn = create_connection()
    print ("Content-type: text/html \n\n");
    if authenticate_user(conn,user,passwd):
        query = 'SELECT PRJ_NAME, ROLE, USER_ID, PRJ_ID from info where USER_NAME="'+str(user)+'" and Password = "'+str(passwd)+'";'
        conn.execute(query)
        res = conn.fetchone()
        prj_name,role,userid,prjid = res[0],res[1],res[2],res[3]
        print ("UAP1",prj_name,role,userid,prjid)
    else:
        print("UAP0")
