#######################################################################
#Application : LAPAM
#Build : v0
#Desc: check whether the log is Apache or IIS 
#Created by : Karpagam
#Modified by: Karpagam
#Date of Modification:8/6/2018
#Reason for modification:Header Added
#code developed as part of story ST008 - Qualify
########################################################################

import shutil,os
from getWSFields import get_iis_fields, get_apache_fields, get_google_fields

def web_check(logpath_file,DATA_PATH,report_name):
    Destination = DATA_PATH
    """iis = get_iis_fields(logpath_file)
    apache = get_apache_fields(logpath_file)
    print(apache)"""
    if get_iis_fields(logpath_file) != "00000":
        DATA_PATH_web = DATA_PATH+"IIS\\"+report_name
        if not os.path.exists(DATA_PATH_web):
            os.mkdir(DATA_PATH_web)
        files = [f for f in os.listdir(DATA_PATH) if os.path.isfile(os.path.join(DATA_PATH, f))]
        shutil.move(os.path.join(DATA_PATH, files[0]), os.path.join(DATA_PATH_web, files[0]))
        logpath_file = DATA_PATH_web+"\\"+files[0]
    elif get_apache_fields(logpath_file) != "00000":
        DATA_PATH_web = DATA_PATH+"Apache\\"+report_name
        if not os.path.exists(DATA_PATH_web):
            os.mkdir(DATA_PATH_web)
        files = [f for f in os.listdir(DATA_PATH) if os.path.isfile(os.path.join(DATA_PATH, f))]
        shutil.move(os.path.join(DATA_PATH, files[0]), os.path.join(DATA_PATH_web, files[0]))
        logpath_file = DATA_PATH_web+"\\"+files[0]
    return logpath_file
